ORIGINAL GAME​

​THE RUMBLE- MOD

Mod for eggnogg+, with 5 new maps, all with different gimmicks.

PIRATES, a fair map with a few obstacles
SWORD CAVERNS, you may not spawn with a sword, but there are plenty around​
​​SPIKE SNIPERS, a map about igniting explosives from below to launch spikes
ONE WAY FUNCTION​, the entrance and the exit to a room aren't the same
SWORD TENNIS, block flying swords with your life!​​

THE EGGNOGG+ MAP EDITOR

The Eggnogg+ Map Creator that I made in Unity. (Because I didn't want to bother with writing GUI code) I initially made it for myself but then got carried away so now there's a 81 MB map editor for a 500kb game that released 8 years ago lol. I wish my own games got this attention madgarden, you're sitting on a goldmine of potential with this game!
(Appearently, "asap" means in "20 months")
(Appearently, "asap" means in "20 months")
Almost all of my work is based on the work of ravary, who compiled a modification guide for this game.  I'm not very good at reverse engineering. My experience is limited to making save editors, so without this guide this wouldn't have been possible.
(Map editor is only for windows and only exports for windows)

AND...
This game is geniunely great. Shame it's so simple. I had trouble coming up with 5 gimmicks!
I had great time playing it with friends on the laptop I brought to gatherings, the only problem is, uh, I got too good at it. Now nobody wants to play with me.